export { automationRoutes } from './routes.js'
