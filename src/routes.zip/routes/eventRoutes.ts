export { eventRoutes } from './routes.js'
