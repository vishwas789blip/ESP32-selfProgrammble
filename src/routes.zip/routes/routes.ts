import { Router } from 'express'
import { authMiddleware } from '../middleware/authMiddleware.js'
import { validate } from '../middleware/validateMiddleware.js'
import { registerSchema, loginSchema } from '../validations/authSchemas.js'
import { deviceSchema, deviceUpdateSchema, deviceConfigSchema } from '../validations/deviceSchemas.js'
import { automationSchema, automationUpdateSchema } from '../validations/automationSchemas.js'
import { authController, deviceController, sensorController, actuatorController, automationController, eventController, aiController } from '../controllers/index.js'
import { aiChatSchema } from '../validations/aiSchemas.js'
import { z } from 'zod'
import { gpioSchema, objectIdSchema } from '../validations/commonSchemas.js'
const sensorSchema = z.object({ name: z.string().trim().min(1).max(100), type: z.string().trim().min(1).max(50), gpio: gpioSchema, value: z.unknown().optional(), unit: z.string().trim().max(30).optional(), status: z.enum(['normal','warning','error']).optional() })
const actuatorSchema = z.object({ name: z.string().trim().min(1).max(100), type: z.string().trim().min(1).max(50), gpio: gpioSchema, state: z.enum(['on','off']).optional() })
const commandSchema = z.object({ command: z.enum(['ON', 'OFF']), duration: z.number().int().positive().max(86400).optional() })
const protectedRouter = () => { const r = Router();
r.use(authMiddleware);
return r }
export const authRoutes = Router();
authRoutes.post('/register', validate(registerSchema), authController.register);
authRoutes.post('/login', validate(loginSchema), authController.login);
authRoutes.get('/me', authMiddleware, authController.me)
export const deviceRoutes = protectedRouter();
deviceRoutes.get('/', deviceController.list);
deviceRoutes.post('/', validate(deviceSchema), deviceController.create);
deviceRoutes.get('/:id', deviceController.get);
deviceRoutes.put('/:id', validate(deviceUpdateSchema), deviceController.update);
deviceRoutes.delete('/:id', deviceController.remove);
deviceRoutes.post('/:id/heartbeat', deviceController.heartbeat);
deviceRoutes.get('/:id/config', deviceController.getConfig);
deviceRoutes.put('/:id/config', validate(deviceConfigSchema), deviceController.updateConfig)
export const sensorRoutes = protectedRouter();
sensorRoutes.get('/devices/:deviceId/sensors', sensorController.list);
sensorRoutes.post('/devices/:deviceId/sensors', validate(sensorSchema), sensorController.create);
sensorRoutes.get('/sensors/:id', sensorController.get);
sensorRoutes.put('/sensors/:id', validate(sensorSchema.partial()), sensorController.update);
sensorRoutes.delete('/sensors/:id', sensorController.remove)
export const actuatorRoutes = protectedRouter();
actuatorRoutes.get('/devices/:deviceId/actuators', actuatorController.list);
actuatorRoutes.post('/devices/:deviceId/actuators', validate(actuatorSchema), actuatorController.create);
actuatorRoutes.put('/actuators/:id', validate(actuatorSchema.partial()), actuatorController.update);
actuatorRoutes.delete('/actuators/:id', actuatorController.remove);
actuatorRoutes.post('/actuators/:id/command', validate(commandSchema), actuatorController.command)
export const automationRoutes = protectedRouter();
automationRoutes.get('/', automationController.list);
automationRoutes.post('/', validate(automationSchema), automationController.create);
automationRoutes.get('/:id', automationController.get);
automationRoutes.put('/:id', validate(automationUpdateSchema), automationController.update);
automationRoutes.delete('/:id', automationController.remove);
automationRoutes.patch('/:id/toggle', automationController.toggle);
automationRoutes.post('/:id/test', automationController.test)
export const eventRoutes = protectedRouter();
eventRoutes.get('/', eventController.list)
export const aiRoutes = protectedRouter();
aiRoutes.post('/chat', validate(aiChatSchema), aiController.chat)
void objectIdSchema