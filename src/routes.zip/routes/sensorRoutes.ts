export { sensorRoutes } from './routes.js'
