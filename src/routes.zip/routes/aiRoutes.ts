export { aiRoutes } from './routes.js'
